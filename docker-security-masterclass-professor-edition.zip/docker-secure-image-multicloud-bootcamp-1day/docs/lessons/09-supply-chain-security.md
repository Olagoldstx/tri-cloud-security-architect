# Lesson 09 — Supply Chain Security

- Produce SBOMs (Syft), scan (Trivy), **sign** (Cosign), and **verify** in deploy pipelines.
- Consider SLSA provenance and in-toto attestations for end-to-end supply chain integrity.
