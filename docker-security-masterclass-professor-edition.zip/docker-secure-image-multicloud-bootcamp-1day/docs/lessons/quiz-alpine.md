# Quiz — Alpine Secure Build

1) Why is Distroless often preferred for production security vs Alpine?  
2) Which flags enforce least privilege at runtime? Name at least 3.  
3) What’s the tradeoff of removing a shell from the runtime image?  
4) How do you generate an SBOM and sign your Alpine image in this repo?
