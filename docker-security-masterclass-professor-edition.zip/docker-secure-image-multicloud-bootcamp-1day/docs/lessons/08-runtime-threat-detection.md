# Lesson 08 — Runtime Threat Detection (Falco)

- Falco uses eBPF/syscall inspection to detect suspicious behavior.
- Run the lab in `docs/lessons/lab-falco.md` to trigger a simple rule and observe alerts.
